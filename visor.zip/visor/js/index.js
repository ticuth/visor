/*jslint devel:true*/
/*jslint browser:true*/
/*global $*/
/*global gui*/
/*global require*/
/*global speechSynthesis*/
/*global SpeechSynthesisUtterance*/
var gui = require('nw.gui');
function getObject(id) {
    'use strict';
	return document.getElementById(id);
}
var app = {

	initialize: function () {
		'use strict';
		app.bindEvents();
		$('#divContent').html('Loading...');
        try {
            app.sayHello();
        } catch (ex1) {
            alert(ex1.message);
        }
        app.loadMain();
	},
    sayHello: function () {
        'use strict';
        var utterance = new SpeechSynthesisUtterance('Hello Treehouse');
        window.speechSynthesis.speak(utterance);
    },
    loadMain: function () {
        'use strict';
        app.getContent('https://raw.githubusercontent.com/ticuth/visor/master/repos.xml', app.getRepos);
    },
    loadNews: function (newsUrl) {
        'use strict';
        app.getContent(newsUrl, app.getNews);
    },
    getRepos: function (data) {
        'use strict';
        try {
            var xmlDoc, xml, shtml, url, title, repos, surl;
            xmlDoc = $.parseXML(data);
            xml = $(xmlDoc);
            shtml = '';
            title = $(xml).find('config>info>name').text();
            $('#divContent').html('Ready.');
            repos = $(xml).find('repos>repolist>repo');
            shtml += '<h1 style="font-weight:lighter;">Repos:</h1><ul>';
            $(repos).each(function () {
                url = $(this).find('url').text();
                surl = ' <span onclick="app.loadNews(\'' + url + '\')" class="clickable glyphicon glyphicon-arrow-right"></span></a>';
                shtml += '<li><span>Repo: ' + $(this).find('name').text() + surl + '</span></li>';
            });
            shtml += '</ul>';
            $('#divContent').html(shtml);
        } catch (e) {
            alert(e.message);
        }
        
    },
    openURL: function (realUrl) {
        'use strict';
        gui.Shell.openExternal(realUrl);
    },
    getNews: function (data) {
        'use strict';
        try {
            var xmlDoc, xml, shtml, url, title, news, surl;
            xmlDoc = $.parseXML(data);
            xml = $(xmlDoc);
            //alert(data);
            shtml = '';
            title = $(xml).find('config>info>name').text();
            $('#divContent').html('Ready.');
            $('#appTitle').html('Visor: ' + title);
            news = $(xml).find('config>newslist>news');
            shtml += '<section class="icons"><ul>';
            $(news).each(function () {
                url = $(this).find('url').text();
                surl = '<span onclick="app.openURL(\'' + url + '\')" class="glyphicon glyphicon-cloud-download"></span></a>';
                shtml += '<li class="action-icon forward"><span>' + $(this).find('description').text() + surl + '</span></li>';
            });
            shtml += '</ul></section>';
            $('#divContent').html(shtml);
        } catch (e) {
            alert(e.message);
        }
    },
    getContent: function (xmlUrl, cb) {
        'use strict';
        var d = new Date();
        $('#statusInfo').show();
        $('#statusInfo').html('Loading');
		$.ajax({
			type: 'GET',
			url: xmlUrl + "?rnd=" + d.getTime(),
			data: {},
			dataType: 'text'
		}).done(function (data) {
            $('#statusInfo').html('Done.');
            $('#statusInfo').fadeOut(1500);
            cb(data);
        }).error(function (xhr, ajaxOptions, thrownError) {
			$('#divContent').html('Error: ' + thrownError);
		});
    },
	bindEvents: function () {
        'use strict';
		getObject('closeApp').onclick = function () {
            $('#myModal').modal();                      // initialized with defaults
            $('#myModal').modal({ keyboard: false });   // initialized with no keyboard
            $('#myModal').modal('show');

		};
	}
};

window.onload = function () {
    'use strict';
	app.initialize();
};